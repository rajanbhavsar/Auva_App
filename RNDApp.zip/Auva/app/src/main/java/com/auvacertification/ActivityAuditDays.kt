package com.auvacertification

import android.content.Intent
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import com.auvacertification.databinding.ActivityCalculateAuditBinding
import com.auvacertification.helper.DataBaseHelper
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.*


class ActivityAuditDays : AppCompatActivity() {
    private var mDb: SQLiteDatabase? = null
    private var mDbHelper: DataBaseHelper? = null
    private lateinit var mActivityBindingAuditBinding: ActivityCalculateAuditBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityBindingAuditBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_calculate_audit)
        val title = intent.getStringExtra("TITLE")
        initToolar(title)
        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.risk_factor,
            R.layout.spinner_custom_textview
        )
        adapter.setDropDownViewResource(R.layout.spinner_custom_textview)
        mActivityBindingAuditBinding.mSpinnerRiskRating.adapter = adapter
        callDatabaseHelper()
        initListener()
    }

    private fun initListener() {
        mActivityBindingAuditBinding.mButtonSubmit.setOnClickListener {
            if (!mActivityBindingAuditBinding.mRadioButtonYesIso9001.isChecked && !mActivityBindingAuditBinding.mRadioButtonYesIso14001.isChecked && !mActivityBindingAuditBinding.mRadioButtonYesIso45001.isChecked) {
                Toast.makeText(
                    this@ActivityAuditDays,
                    getString(R.string.alert_select_ISO_standard),
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }

            if (mActivityBindingAuditBinding.mEditTextNoEmployee.text != null && mActivityBindingAuditBinding.mEditTextNoEmployee.text.toString()
                    .trim().isNotEmpty()
                && mActivityBindingAuditBinding.mEditTextNoEmployee.text.toString()
                    .trim()
                    .toInt() >= 0 && mActivityBindingAuditBinding.mEditTextPerformSameTask.text != null && mActivityBindingAuditBinding.mEditTextPerformSameTask.text.toString()
                    .trim().isNotEmpty()
                && mActivityBindingAuditBinding.mEditTextPerformSameTask.text.toString()
                    .trim().toInt() >= 0
            ) {
                if (mActivityBindingAuditBinding.mEditTextEffectiveEmployee.text != null && mActivityBindingAuditBinding.mEditTextEffectiveEmployee.text.toString()
                        .trim().isNotEmpty()
                    && mActivityBindingAuditBinding.mEditTextEffectiveEmployee.text.toString()
                        .trim().toInt() >= 0
                ) {
                    callFunction(
                        mActivityBindingAuditBinding.mEditTextEffectiveEmployee.text.toString()
                            .trim(),
                        mActivityBindingAuditBinding.mSpinnerRiskRating.selectedItem.toString()
                    )
                } else {
                    Toast.makeText(
                        this@ActivityAuditDays,
                        getString(R.string.alert_audit_no_ofemployee),
                        Toast.LENGTH_LONG
                    ).show()
                }
            } else {
                Toast.makeText(
                    this@ActivityAuditDays,
                    getString(R.string.alert_audit_no_ofemployee),
                    Toast.LENGTH_LONG
                ).show()
            }

        }

        mActivityBindingAuditBinding.mEditTextNoEmployee.addTextChangedListener(object :
            TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                udateEffectiveNoOfEmloyee()
            }

        })

        mActivityBindingAuditBinding.mEditTextPerformSameTask.addTextChangedListener(object :
            TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable?) {
                udateEffectiveNoOfEmloyee()
            }

        })

        checkForBottomSpinnerListener()
    }

    private fun checkForBottomSpinnerListener() {

        //For Yes
        mActivityBindingAuditBinding.mRadioButtonYesIso9001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }

        mActivityBindingAuditBinding.mRadioButtonYesIso14001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }

        mActivityBindingAuditBinding.mRadioButtonYesIso45001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }

        //For No
        mActivityBindingAuditBinding.mRadioButtonNoIso9001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }

        mActivityBindingAuditBinding.mRadioButtonNoIso14001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }

        mActivityBindingAuditBinding.mRadioButtonNoIso45001.setOnCheckedChangeListener { _, isChecked ->
            displayRiskFactor()
        }
    }

    fun displayRiskFactor() {

        if (mActivityBindingAuditBinding.mRadioButtonYesIso14001.isChecked || mActivityBindingAuditBinding.mRadioButtonYesIso45001.isChecked) {
            mActivityBindingAuditBinding.mTextViewRiskRating.visibility = View.VISIBLE
            mActivityBindingAuditBinding.mSpinnerRiskRating.visibility = View.VISIBLE
        } else {
            mActivityBindingAuditBinding.mTextViewRiskRating.visibility = View.GONE
            mActivityBindingAuditBinding.mSpinnerRiskRating.visibility = View.GONE
        }
    }

    private fun udateEffectiveNoOfEmloyee() {
        val intNoOfEmployee =
            if (mActivityBindingAuditBinding.mEditTextNoEmployee.text.isNullOrEmpty()) 0 else mActivityBindingAuditBinding.mEditTextNoEmployee.text.toString()
                .trim().toInt()
        val intPerformTask =
            if (mActivityBindingAuditBinding.mEditTextPerformSameTask.text.isNullOrEmpty()) 0 else
                mActivityBindingAuditBinding.mEditTextPerformSameTask.text.toString().trim().toInt()
        mActivityBindingAuditBinding.mEditTextEffectiveEmployee.setText(
            intNoOfEmployee.minus(
                intPerformTask
            ).toString()
        )
        /*"" +
            (mActivityBindingAuditBinding.mEditTextNoEmployee.text.toString().trim())
                .toInt().minus (mActivityBindingAuditBinding.mEditTextPerformSameTask.text.toString()
        .trim().toInt())*/
    }

    private fun callFunction(valueTo: String, priority: String) {
        val arrayListOfQuery = arrayListOf<String>()
        if (mActivityBindingAuditBinding.mRadioButtonYesIso9001.isChecked) {
            arrayListOfQuery.add("SELECT Stage,AnnualSurveillance as Surveillance,ReAssessment FROM QMS WHERE $valueTo BETWEEN EmployeeFrom AND EmployeeTo")
        }
        if (mActivityBindingAuditBinding.mRadioButtonYesIso14001.isChecked) {
            arrayListOfQuery.add("SELECT CASE WHEN '" + priority + "' = 'High' THEN HighStage WHEN '" + priority + "' = 'Medium' Then MediumStage WHEN '" + priority + "' = 'Low' Then LowStage WHEN '" + priority + "' = 'Limited' Then LimitedStage END as Stage, CASE WHEN '" + priority + "' = 'High' THEN HighSurveillance WHEN '" + priority + "' = 'Medium' Then MediumSurveillance WHEN '" + priority + "' = 'Low' Then LowSurveillance WHEN '" + priority + "' = 'Limited' Then LimitedSurveillance END as Surveillance, CASE WHEN '" + priority + "' = 'High' THEN HighReAssessment WHEN '" + priority + "' = 'Medium' Then MediumReAssessment WHEN '" + priority + "' = 'Low' Then LowReAssessment WHEN '" + priority + "' = 'Limited' Then LimitedReAssessment END as ReAssessment FROM EMS where $valueTo between EmployeeFrom AND EmployeeTo")
        }
        if (mActivityBindingAuditBinding.mRadioButtonYesIso45001.isChecked) {
            arrayListOfQuery.add("SELECT CASE WHEN '" + priority + "' = 'High' THEN HighStage WHEN '" + priority + "' = 'Medium' Then MediumStage WHEN '" + priority + "' = 'Low' Then LowStage END as Stage, CASE WHEN '" + priority + "' = 'High' THEN HighSurveillance WHEN '" + priority + "' = 'Medium' Then MediumSurveillance WHEN '" + priority + "' = 'Low' Then LowSurveillance END as Surveillance, CASE WHEN '" + priority + "' = 'High' THEN HighReAssessment WHEN '" + priority + "' = 'Medium' Then MediumReAssessment WHEN '" + priority + "' = 'Low' Then LowReAssessment END as ReAssessment FROM OHS where $valueTo between EmployeeFrom AND EmployeeTo")
        }
        var totalDaysStage = 0.00
        var totalDaysSurveillance1 = 0.00
        var totalDaysSurveillance2 = 0.00
        var totalDaysReAssessment = 0.00
        try {
            for (query in arrayListOfQuery) {
                //Log.e("Query---", query)
                val mCur = mDb?.rawQuery(query, null)
                mCur?.moveToFirst()
                do {
                    val stage = (mCur?.getString(mCur.getColumnIndex("Stage")))!!.toDouble()
                    val surveillance =
                        (mCur.getString(mCur.getColumnIndex("Surveillance")))!!.toDouble()
                    val ReAssessment =
                        (mCur.getString(mCur.getColumnIndex("ReAssessment")))!!.toDouble()

                    //Log.e("Stage---", "" + stage)
                    //Log.e("surveillance---", "" + surveillance)
                    //Log.e("ReAssessment---", "" + ReAssessment)
                    totalDaysStage += stage
                    totalDaysSurveillance1 += surveillance
                    totalDaysReAssessment += ReAssessment
                } while (mCur?.moveToNext()!!)
                mCur.close()
            }
        } catch (mSQLException: SQLException) {
            //Log.e("SQLException", "getTestData >>$mSQLException")
            throw mSQLException
        }
        //Log.e("Total Days---", "" + totalDaysStage)
        //Log.e("Total Surveillance Days---", "" + totalDaysSurveillance1)
        //Log.e("Total ReAssessment Days---", "" + totalDaysReAssessment)


        if (checkForBelowCalculation()) {
            val percentageValueofTotalStage = totalDaysStage * (1 - (20 / 100.0f))
            val percentageValueofSurveillance = totalDaysSurveillance1 * (1 - (20 / 100.0f))
            val percentageValueofReAssessment = totalDaysReAssessment * (1 - (20 / 100.0f))

            callActivityResult(
                Math.ceil(getFormattedValue(percentageValueofTotalStage) / 0.5) * 0.5,
                Math.ceil(getFormattedValue(percentageValueofSurveillance) / 0.5) * 0.5,
                Math.ceil(getFormattedValue(percentageValueofReAssessment) / 0.5) * 0.5
            )
        } else {

            val percentageValueofTotalStage = totalDaysStage
            val percentageValueofSurveillance = totalDaysSurveillance1
            val percentageValueofReAssessment = totalDaysReAssessment


            callActivityResult(
                Math.ceil(getFormattedValue(percentageValueofTotalStage) / 0.5) * 0.5,
                Math.ceil(getFormattedValue(percentageValueofSurveillance) / 0.5) * 0.5,
                Math.ceil(getFormattedValue(percentageValueofReAssessment) / 0.5) * 0.5
            )
        }


        /*  Log.e(
              "Total Days with Reduction---",
              "" + round(getFormattedValue(percentageValueofTotalStage).toDouble() * 20 / 20)
          )
          Log.e(
              "Total Surveillance Days with Reduction---",
              "" + round(getFormattedValue(percentageValueofSurveillance).toDouble() * 2 / 2)
          )
          Log.e(
              "Total ReAssessment Days with Reduction---",
              "" + round(getFormattedValue(percentageValueofReAssessment).toDouble() * 2 / 2)
          )*/
//double round = Math.ceil(7.20 /0.5) * 0.5;

    }

    private fun checkForBelowCalculation(): Boolean {
        var int = 0
        if (mActivityBindingAuditBinding.mRadioButtonYesIso9001.isChecked) {
            int++
        }
        if (mActivityBindingAuditBinding.mRadioButtonYesIso14001.isChecked) {
            int++
        }
        if (mActivityBindingAuditBinding.mRadioButtonYesIso45001.isChecked) {
            int++
        }
        //Log.e("Deduction Allowed--", (int > 1).toString())
        return int > 1

    }

    private fun callActivityResult(
        percentageValueofTotalStage: Double,
        percentageValueofSurveillance: Double,
        percentageValueofReAssessment: Double
    ) {
        val intent = Intent(this, ActivityResult::class.java)
        intent.putExtra("TITLE", getString(R.string.label_result))
        intent.putExtra("STAGE12", "" + percentageValueofTotalStage)
        intent.putExtra("SURVEILLANCE1", "" + percentageValueofSurveillance)
        intent.putExtra("SURVEILLANCE2", "" + percentageValueofReAssessment)
        startActivity(intent)
    }

    fun getFormattedValue(value: Double): Double {
        val symbols = DecimalFormatSymbols(Locale.ENGLISH)
        symbols.decimalSeparator = '.'
        val mDecimalFormat = DecimalFormat("0.00", symbols)
        return mDecimalFormat.format(value).toDouble()
    }

    private fun callDatabaseHelper() {
        mDbHelper = DataBaseHelper(this)
        mDbHelper?.createDataBase()
        mDbHelper?.openDataBase()
        mDb = mDbHelper?.readableDatabase
    }


    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityBindingAuditBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }
}