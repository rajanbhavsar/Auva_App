package com.auvacertification

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import com.auvacertification.databinding.ActivityCmspageBinding


class ActivityCMSPage : AppCompatActivity() {

    private lateinit var mActivityCmspageBinding: ActivityCmspageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityCmspageBinding = DataBindingUtil.setContentView(this, R.layout.activity_cmspage)
        val pageUrl = intent.getStringExtra("PAGE_URL")
        val title = intent.getStringExtra("TITLE")
        initToolar(title)
        mActivityCmspageBinding.mWebView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, progress: Int) {
                //Make the bar disappear after URL is loaded, and changes string to Loading...
                if (progress >= 100)
                    mActivityCmspageBinding.mProgressBar.visibility = View.GONE
            }


        }

        mActivityCmspageBinding.mWebView.webViewClient = MyWebViewClient()
        mActivityCmspageBinding.mWebView.settings.javaScriptEnabled = true
        mActivityCmspageBinding.mWebView.settings.loadsImagesAutomatically = true
        mActivityCmspageBinding.mWebView.scrollBarStyle = View.SCROLLBARS_INSIDE_OVERLAY
        pageUrl?.let {
            mActivityCmspageBinding.mProgressBar.visibility = View.VISIBLE
            mActivityCmspageBinding.mWebView.loadUrl(it)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // handle arrow click here
        if (item.itemId === android.R.id.home) {
            finish() // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item)
    }

    class MyWebViewClient : WebViewClient() {
        //        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap) {
//        }
//
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }
    }

    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityCmspageBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }
}