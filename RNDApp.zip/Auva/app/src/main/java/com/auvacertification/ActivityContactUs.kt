package com.auvacertification

import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.viewpager2.widget.ViewPager2
import com.auvacertification.adapter.ViewPagerAdapter
import com.auvacertification.databinding.ActivityContactusBinding
import com.auvacertification.model.ContactUsModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator


class ActivityContactUs : AppCompatActivity() {

    private lateinit var mActivityContactusBinding: ActivityContactusBinding
    private var listOfContactUs = arrayListOf<ContactUsModel>()
    private var hashMapOfContactUs = LinkedHashMap<String, List<ContactUsModel>>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityContactusBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_contactus)
        val title = intent.getStringExtra("TITLE")
        initToolar(title)
        mActivityContactusBinding.mViewPager2.registerOnPageChangeCallback(object :
            ViewPager2.OnPageChangeCallback() {

            override fun onPageScrollStateChanged(state: Int) {
                super.onPageScrollStateChanged(state)
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels)
            }

            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
            }

        })

        val adapter = ViewPagerAdapter(this)
        mActivityContactusBinding.mViewPager2.adapter = adapter
        listOfContactUs.add(
            ContactUsModel(
                "Address",
                "Little Braxted Hall,Little Braxted,Essex, CM8 3EU,United Kingdom",
                ContextCompat.getDrawable(this, R.drawable.ic_home)!!,
                "GET IN TOUCH",
                "Location"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Phone",
                "01376 386110",
                ContextCompat.getDrawable(this, R.drawable.ic_telephone)!!,
                "CALL",
                "CALL"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Email",
                "info@auvacertification.com",
                ContextCompat.getDrawable(this, R.drawable.ic_email)!!,
                "EMAIL US",
                "EMAIL"
            )
        )
        hashMapOfContactUs["Head Office"] = listOfContactUs
        listOfContactUs = arrayListOf<ContactUsModel>()
        listOfContactUs.add(
            ContactUsModel(
                "Address",
                "12 Cloghog Road, Coalisland,Co. Tyrone,BT71 5EH",
                ContextCompat.getDrawable(this, R.drawable.ic_home)!!,
                "GET IN TOUCH",
                "Location"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Phone",
                "028 9099 1009",
                ContextCompat.getDrawable(this, R.drawable.ic_telephone)!!,
                "CALL",
                "CALL"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Email",
                "paula@auvacertification.com",
                ContextCompat.getDrawable(this, R.drawable.ic_email)!!,
                "EMAIL US",
                "EMAIL"
            )
        )
        hashMapOfContactUs["Northern Ireland Office"] = listOfContactUs

        listOfContactUs = arrayListOf<ContactUsModel>()
        listOfContactUs.add(
            ContactUsModel(
                "Address",
                "4682 Brompton Drive, Buffalo, New York, 14219U,USA",
                ContextCompat.getDrawable(this, R.drawable.ic_home)!!,
                "GET IN TOUCH",
                "Location"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Phone",
                "352-572-3082",
                ContextCompat.getDrawable(this, R.drawable.ic_telephone)!!,
                "CALL",
                "CALL"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Email",
                "brian@auvacertification.com",
                ContextCompat.getDrawable(this, R.drawable.ic_email)!!,
                "EMAIL US",
                "EMAIL"
            )
        )
        hashMapOfContactUs["USA Sales Office"] = listOfContactUs

        listOfContactUs = arrayListOf<ContactUsModel>()
        listOfContactUs.add(
            ContactUsModel(
                "Address",
                "Coosan, Athlone, Co. Westmeath, N37 T2D6",
                ContextCompat.getDrawable(this, R.drawable.ic_home)!!,
                "GET IN TOUCH",
                "Location"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Phone",
                "0857 304294",
                ContextCompat.getDrawable(this, R.drawable.ic_telephone)!!,
                "CALL",
                "CALL"
            )
        )
        listOfContactUs.add(
            ContactUsModel(
                "Email",
                "tony@auvacertification.com",
                ContextCompat.getDrawable(this, R.drawable.ic_email)!!,
                "EMAIL US",
                "EMAIL"
            )
        )
        hashMapOfContactUs["Republic Of Ireland Office"] = listOfContactUs
        var keys = arrayListOf<String>()
        for ((k, v) in hashMapOfContactUs) {
            println("$k = $v")
            keys.add(k)
        }
        adapter.setData(hashMapOfContactUs, keys)
        TabLayoutMediator(
            mActivityContactusBinding.mTablayout,
            mActivityContactusBinding.mViewPager2
        ) { tab, position ->
            tab.customView = getTabItem(keys, position)
            tab.text = keys[position]
        }.attach()
        mActivityContactusBinding.mTablayout.addOnTabSelectedListener(object :
            TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {
            }

        })
        mActivityContactusBinding.mTablayout.selectTab(
            mActivityContactusBinding.mTablayout.getTabAt(
                0
            )
        )
    }

    private fun getTabItem(keys: ArrayList<String>, position: Int): View {
        val tabOne = LayoutInflater.from(this).inflate(R.layout.custom_tab, null) as RelativeLayout
        tabOne.findViewById<AppCompatTextView>(R.id.tab).text = keys[position];
        return tabOne
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // handle arrow click here
        if (item.itemId === android.R.id.home) {
            finish() // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item)
    }

    class MyWebViewClient : WebViewClient() {
        //        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap) {
//        }
//
        override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            view.loadUrl(url)
            return true
        }
    }

    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityContactusBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }


}