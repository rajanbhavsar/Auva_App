package com.auvacertification

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import com.auvacertification.databinding.ActivityMainBinding


class ActivityDashboard : AppCompatActivity() {

    lateinit var mActivityDashboardBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityDashboardBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_main)
        initToolar()
        initListener()
    }

    private fun initListener() {
        mActivityDashboardBinding.mLinearWebsite.setOnClickListener {
            val intent = Intent(this@ActivityDashboard, ActivityCMSPage::class.java)
            intent.putExtra("PAGE_URL", BuildConfig.WEBSITE)
            intent.putExtra("TITLE", getString(R.string.label_website))
            startActivity(intent)
        }


        mActivityDashboardBinding.mLinearContactUs.setOnClickListener {
            val intent = Intent(this@ActivityDashboard, ActivityContactUs::class.java)
            intent.putExtra("TITLE", getString(R.string.label_contact_us))
            startActivity(intent)
        }
        mActivityDashboardBinding.mLinearAudit?.setOnClickListener {
            val intent = Intent(this@ActivityDashboard, ActivityAuditDays::class.java)
            intent.putExtra("TITLE", getString(R.string.label_calculate_audit_days))
            startActivity(intent)
        }

        mActivityDashboardBinding.mLinearNewsLetter.setOnClickListener {
            val intent = Intent(this@ActivityDashboard, ActivityNewsLetter::class.java)
            startActivity(intent)
        }

        mActivityDashboardBinding.mTextViewQuote.setOnClickListener {
            val intent = Intent(this@ActivityDashboard, ActivityCMSPage::class.java)
            intent.putExtra("PAGE_URL", "https://auvacertification.com/audit-application-2/")
            intent.putExtra("TITLE", getString(R.string.label_get_a_quote))
            startActivity(intent)
        }
    }

    private fun initToolar() {
        val toolbar: Toolbar = mActivityDashboardBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
        toolbar.title = getString(R.string.app_name)
        toolbar.setBackgroundColor(ContextCompat.getColor(this, R.color.color_common))
// Remove default title text
// Remove default title text
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        val mImageViewLogo = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewLogo)
        mImageViewLogo.visibility = View.VISIBLE
        mTitle.visibility = View.GONE
        mTitle.text = getString(R.string.app_name)
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.GONE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }
}