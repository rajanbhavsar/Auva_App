package com.auvacertification

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.DividerItemDecoration
import com.auvacertification.adapter.NewsLetterRecycleViewAdapter
import com.auvacertification.databinding.ActivityNewsletterBinding
import com.auvacertification.listener.NewsLetterClick
import com.auvacertification.model.NewsLetter

class ActivityNewsLetter : AppCompatActivity(), NewsLetterClick {

    private lateinit var mActivityDataBinding: ActivityNewsletterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityDataBinding = DataBindingUtil.setContentView(this, R.layout.activity_newsletter)
        initToolar(getString(R.string.label_news_letter))
        populateNewsLetterItems()
    }

    private fun populateNewsLetterItems() {
        val listOfNewsLetter = arrayListOf<NewsLetter>()
        listOfNewsLetter.add(
            NewsLetter(
                "November 2020",
                "https://auvacertification.com/wp-content/uploads/2020/11/AUVA-newsletter-Nov-2020-V2.pdf"
            )
        )
        listOfNewsLetter.add(
            NewsLetter(
                "July 2020",
                "https://auvacertification.com/wp-content/uploads/2020/07/AUVA-newsletter-July-2020-V3.pdf"
            )
        )
        listOfNewsLetter.add(
            NewsLetter(
                "April 2020",
                "https://auvacertification.com/wp-content/uploads/2020/04/AUVA-newsletter-April-2020.pdf"
            )
        )


        val newsletterAdapter = NewsLetterRecycleViewAdapter(listOfNewsLetter, this)
        mActivityDataBinding.mRecycleViewNewsLetter.adapter = newsletterAdapter
        val dividerDecoration = DividerItemDecoration(
            this,
            LinearLayout.VERTICAL
        )
        ContextCompat.getDrawable(this, R.drawable.divider)
            ?.let { dividerDecoration.setDrawable(it) }
        mActivityDataBinding.mRecycleViewNewsLetter.addItemDecoration(
            dividerDecoration
        )
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // handle arrow click here
        if (item.itemId === android.R.id.home) {
            finish() // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item)
    }


    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityDataBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }

    override fun newsLetterClicked(newsLetter: NewsLetter) {
        val intent = Intent(this, ActivityNewsLetterDetail::class.java)
        intent.putExtra("TITLE", newsLetter.title)
        intent.putExtra("PAGE_URL", newsLetter.url)
        startActivity(intent)
    }
}