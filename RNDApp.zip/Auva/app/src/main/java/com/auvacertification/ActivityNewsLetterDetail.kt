package com.auvacertification

import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import com.auvacertification.databinding.ActivityNewsletterDetailBinding
import com.auvacertification.pdfrender.Quality
import java.util.*


class ActivityNewsLetterDetail : AppCompatActivity() {

    private lateinit var mActivityNewsletterDetailBinding: ActivityNewsletterDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityNewsletterDetailBinding =
            DataBindingUtil.setContentView(this, R.layout.activity_newsletter_detail)
        intent.getStringExtra("PAGE_URL")?.let {
            mActivityNewsletterDetailBinding.pdfView.initWithUrl(
                it,
                Quality.NORMAL,
                mActivityNewsletterDetailBinding,
                "Statement" + "_" + Calendar.getInstance().timeInMillis
            )
        }
        initToolar(intent.getStringExtra("TITLE"))

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // handle arrow click here
        if (item.itemId === android.R.id.home) {
            finish() // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item)
    }


    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityNewsletterDetailBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }
}