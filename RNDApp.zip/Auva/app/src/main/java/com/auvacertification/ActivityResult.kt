package com.auvacertification

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageView
import androidx.appcompat.widget.AppCompatTextView
import androidx.appcompat.widget.Toolbar
import androidx.databinding.DataBindingUtil
import com.auvacertification.databinding.ActivityResultBinding


class ActivityResult : AppCompatActivity() {

    private lateinit var mActivityResultBinding: ActivityResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mActivityResultBinding = DataBindingUtil.setContentView(this, R.layout.activity_result)
        val title = intent.getStringExtra("TITLE")
        val STAGE12 = intent.getStringExtra("STAGE12")
        val SURVEILLANCE1 = intent.getStringExtra("SURVEILLANCE1")
        val SURVEILLANCE2 = intent.getStringExtra("SURVEILLANCE2")

        mActivityResultBinding.mTextViewStage1Stage2Days.text =
            getString(R.string.label_stage_1_and_stage_2_total_days) + " " + STAGE12
        mActivityResultBinding.mTextViewSurveillanceDays.text =
            getString(R.string.label_surveillance_days_year_1) + " " + SURVEILLANCE1
        mActivityResultBinding.mTextViewSurveillanceDays2.text =
            getString(R.string.label_surveillance_days_year_2) + " " + SURVEILLANCE1
        mActivityResultBinding.mTextViewReAssessment.text =
            getString(R.string.label_re_assessment) + " " + SURVEILLANCE2
        initToolar(title)

        mActivityResultBinding.mTextViewQuote.setOnClickListener {
            val intent = Intent(this@ActivityResult, ActivityCMSPage::class.java)
            intent.putExtra("PAGE_URL", "https://auvacertification.com/audit-application-2/")
            intent.putExtra("TITLE", getString(R.string.label_get_a_quote))
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // handle arrow click here
        if (item.itemId === android.R.id.home) {
            finish() // close this activity and return to preview activity (if there is any)
        }
        return super.onOptionsItemSelected(item)
    }

    private fun initToolar(title: String?) {
        val toolbar: Toolbar = mActivityResultBinding.mToolbar as Toolbar
        setSupportActionBar(toolbar)
// Remove default title text
// Remove default title text
        supportActionBar?.setDisplayShowTitleEnabled(false)
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
// Get access to the custom title view
// Get access to the custom title view
        val mTitle = toolbar.findViewById<AppCompatTextView>(R.id.toolbar_title)
        mTitle.text = title
        displayBackButtonEvent(toolbar)
    }

    private fun displayBackButtonEvent(toolbar: Toolbar) {
        val mImageViewBack = toolbar.findViewById<AppCompatImageView>(R.id.mImageViewBack)
        mImageViewBack.visibility = View.VISIBLE
        mImageViewBack.setOnClickListener {
            onBackPressed()
        }
    }
}