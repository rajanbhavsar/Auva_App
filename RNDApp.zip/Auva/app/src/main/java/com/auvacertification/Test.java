package com.auvacertification;

public class Test {


    public static void main(String[] args){

        double round = Math.ceil(7.20 /0.5) * 0.5;
        System.out.println(round);
    }
}
