package com.auvacertification.adapter

import android.graphics.drawable.Drawable
import android.widget.ImageView
import androidx.databinding.BindingAdapter

class BindingAdapterUtils {

    companion object{

        @JvmStatic
        @BindingAdapter("srcCompat")
        fun setSrcCompat(view: ImageView, drawable: Drawable) {
            view.setImageDrawable(drawable)
        }

    }
}