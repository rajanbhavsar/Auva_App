package com.auvacertification.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.auvacertification.R
import com.auvacertification.databinding.ItemContactusBinding
import com.auvacertification.listener.NewsLetterClickListener
import com.auvacertification.model.ContactUsModel


class ContactUsAdapter(
    private val lisOfContactUs: List<ContactUsModel>,
    private val listener: NewsLetterClickListener
) :
    RecyclerView.Adapter<ContactUsAdapter.ViewHolder>() {


    inner class ViewHolder(var itemRowBinding: ItemContactusBinding) :
        RecyclerView.ViewHolder(itemRowBinding.root) {


        fun bind(obj: ContactUsModel) {
            itemRowBinding.contactUs = obj
            itemRowBinding.executePendingBindings()
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: ItemContactusBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_contactus, parent, false
        )

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val newsletterItem = lisOfContactUs[position]
        holder.bind(newsletterItem)
        holder.itemView.setOnClickListener {
            listener.newsLetterClicked(newsletterItem)
        }
    }

    override fun getItemCount(): Int {
        return lisOfContactUs.size
    }

}