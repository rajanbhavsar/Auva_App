package com.auvacertification.adapter


import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.auvacertification.R
import com.auvacertification.databinding.ItemNewsletterBinding
import com.auvacertification.listener.NewsLetterClick
import com.auvacertification.model.NewsLetter


class NewsLetterRecycleViewAdapter(
    private val listOfNewsLetter: List<NewsLetter>,
    private val listener: NewsLetterClick
) :
    RecyclerView.Adapter<NewsLetterRecycleViewAdapter.ViewHolder>() {


    inner class ViewHolder(var itemRowBinding: ItemNewsletterBinding) :
        RecyclerView.ViewHolder(itemRowBinding.root) {


        fun bind(obj: NewsLetter) {
            itemRowBinding.newsletter = obj
            itemRowBinding.executePendingBindings()
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: ItemNewsletterBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_newsletter, parent, false
        )

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val newsletterItem = listOfNewsLetter[position]
        holder.bind(newsletterItem)
        holder.itemView.setOnClickListener {
            listener.newsLetterClicked(newsletterItem)
        }
    }

    override fun getItemCount(): Int {
        return listOfNewsLetter.size
    }

}