package com.auvacertification.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.auvacertification.R
import com.auvacertification.databinding.ItemViewpagerBinding
import com.auvacertification.listener.NewsLetterClickListener
import com.auvacertification.model.ContactUsModel


class ViewPagerAdapter(val mContext: Context) :
    RecyclerView.Adapter<ViewPagerAdapter.ViewHolder>(), NewsLetterClickListener {

    var hashMapOfContactUs: LinkedHashMap<String, List<ContactUsModel>> =
        LinkedHashMap()
    var Hashkeys = arrayListOf<String>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding: ItemViewpagerBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_viewpager, parent, false
        )
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return hashMapOfContactUs.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        hashMapOfContactUs[Hashkeys[position]]?.let { holder.onBindView(it) }
    }


    fun setData(array: LinkedHashMap<String, List<ContactUsModel>>, keys: ArrayList<String>) {
        hashMapOfContactUs.putAll(array)
        Hashkeys.addAll(keys)
        hashMapOfContactUs.let {
            if (it.size > 0) {
                notifyDataSetChanged()
            }
        }
    }

    inner class ViewHolder(
        var itemViewpagerBinding: ItemViewpagerBinding
    ) :
        RecyclerView.ViewHolder(itemViewpagerBinding.root) {
        fun onBindView(commonData: List<ContactUsModel>) {
            itemViewpagerBinding.mRecycleViewContactUs.adapter =
                ContactUsAdapter(commonData, this@ViewPagerAdapter)
        }
    }

    override fun newsLetterClicked(newsLetter: ContactUsModel) {
        if (newsLetter.action.equals("CALL")) {
            callActivityDefault(newsLetter.address)
        }
        if (newsLetter.action.equals("EMAIL US")) {
            emailActivityDefault(newsLetter.address)
        }
        if (newsLetter.action.equals("GET IN TOUCH")) {
            callMapActivity(newsLetter.address)
        }

    }

    private fun callMapActivity(address: String) {
        val mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        val mapIntent = Intent(Intent.ACTION_VIEW, mapUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        mContext.startActivity(mapIntent)

    }

    private fun emailActivityDefault(email: String) {
        /*ACTION_SEND action to launch an email client installed on your Android device.*/
        val mIntent = Intent(Intent.ACTION_SEND)
        /*To send an email you need to specify mailto: as URI using setData() method
        and data type will be to text/plain using setType() method*/
        mIntent.data = Uri.parse("mailto:")
        mIntent.type = "text/plain"
        // put recipient email in intent
        /* recipient is put as array because you may wanna send email to multiple emails
           so enter comma(,) separated emails, it will be stored in array*/
        mIntent.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
        //put the Subject in the intent
        mIntent.putExtra(Intent.EXTRA_SUBJECT, "")
        //put the message in the intent
        mIntent.putExtra(Intent.EXTRA_TEXT, "")


        try {
            //start email intent
            mContext.startActivity(Intent.createChooser(mIntent, "Choose Email Client..."))
        } catch (e: Exception) {
            //if any thing goes wrong for example no email client application or any exception
            //get and show exception message
            Toast.makeText(mContext, e.message, Toast.LENGTH_LONG).show()
        }
    }

    private fun callActivityDefault(address: String) {
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse("tel:$address")
        mContext.startActivity(intent)
    }
}