package com.auvacertification

import androidx.databinding.ObservableInt

data class Audit(
    val noIfEmployee: ObservableInt,
    val performTask: ObservableInt,
    val effectiveEmployee: ObservableInt
)
