package com.auvacertification.helper

import android.content.Context
import android.database.SQLException
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.io.*


class DataBaseHelper(context: Context) :
    SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val DB_FILE: File
    private var mDataBase: SQLiteDatabase? = null
    private val mContext: Context

    @Throws(IOException::class)
    fun createDataBase() {
        // If the database does not exist, copy it from the assets.
        val mDataBaseExist = checkDataBase()
        if (!mDataBaseExist) {
            this.readableDatabase
            close()
            try {
                // Copy the database from assests
                copyDataBase()
                //Log.e(TAG, "createDatabase database created")
            } catch (mIOException: IOException) {
                throw Error("ErrorCopyingDataBase")
            }
        }
    }

    // Check that the database file exists in databases folder
    private fun checkDataBase(): Boolean {
        return DB_FILE.exists()
    }

    // Copy the database from assets
    @Throws(IOException::class)
    private fun copyDataBase() {
        val mInput: InputStream = mContext.getAssets().open(DB_NAME)
        val mOutput: OutputStream = FileOutputStream(DB_FILE)
        val mBuffer = ByteArray(1024)
        var mLength: Int
        while (mInput.read(mBuffer).also { mLength = it } > 0) {
            mOutput.write(mBuffer, 0, mLength)
        }
        mOutput.flush()
        mOutput.close()
        mInput.close()
    }

    // Open the database, so we can query it
    @Throws(SQLException::class)
    fun openDataBase(): Boolean {
        // Log.v("DB_PATH", DB_FILE.getAbsolutePath());
        mDataBase = SQLiteDatabase.openDatabase(
            DB_FILE.toString(),
            null,
            SQLiteDatabase.CREATE_IF_NECESSARY
        )
        // mDataBase = SQLiteDatabase.openDatabase(DB_FILE, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        return mDataBase != null
    }

    @Synchronized
    override fun close() {
        if (mDataBase != null) {
            mDataBase!!.close()
        }
        super.close()
    }

    override fun onCreate(db: SQLiteDatabase?) {
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
    }

    companion object {
        private const val TAG = "DataBaseHelper" // Tag just for the LogCat window
        private const val DB_NAME = "review.db" // Database name
        private const val DB_VERSION = 1 // Database version
    }

    init {
        DB_FILE = context.getDatabasePath(DB_NAME)
        mContext = context
    }
}