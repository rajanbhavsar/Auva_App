package com.auvacertification.listener

import com.auvacertification.model.NewsLetter

interface NewsLetterClick {

    fun newsLetterClicked(newsLetter: NewsLetter)
}