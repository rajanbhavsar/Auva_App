package com.auvacertification.listener

import com.auvacertification.model.ContactUsModel

interface NewsLetterClickListener {

    fun newsLetterClicked(newsLetter: ContactUsModel)
}