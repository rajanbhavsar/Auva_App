package com.auvacertification.model

import android.graphics.drawable.Drawable

data class ContactUsModel(
    val title: String,
    var address: String,
    var resourcId: Drawable,
    var action: String,
    var actionType: String
)
