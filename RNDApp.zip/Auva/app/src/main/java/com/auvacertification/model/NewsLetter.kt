package com.auvacertification.model

data class NewsLetter(val title: String, var url : String)
