package com.auvacertification.pdfrender

enum class Engine(val value: Int) {
    DEFAULT(100),
    GOOGLE(200)
}
