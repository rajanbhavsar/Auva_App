package com.auvacertification.pdfrender

enum class Quality(val ratio: Int) {
    FAST(1),
    NORMAL(2),
    ENHANCED(3)
}
